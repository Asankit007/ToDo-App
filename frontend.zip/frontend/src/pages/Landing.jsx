import Lottie from "lottie-react";
import todoAnimation from "../assets/animations/todo.json";

export default function Landing() {
  return (
    <div className="min-h-screen bg-[#C2E7D3] flex items-center justify-center px-6">

      <div className="bg-white border rounded-2xl shadow-md p-10 max-w-5xl w-full grid grid-cols-1 lg:grid-cols-2 gap-10">

        {/* Animation Section */}
        <div className="flex items-center justify-center">
          <Lottie
            animationData={todoAnimation}
            loop={true}
            style={{ width: "90%", height: "90%" }}
          />
        </div>

        {/* Text Section */}
        <div className="flex flex-col justify-center">
          <h1 className="text-4xl font-bold text-gray-800 mb-4">To-Do List Manager</h1>

          <p className="text-gray-600 mb-8">
            Organize your tasks, track your progress, and stay productive with your
            modern task management application.
          </p>

          <div className="flex gap-4">
            <a
              href="/login"
              className="bg-green-600 text-white px-6 py-3 rounded-lg text-lg hover:bg-blue-700 transition"
            >
              Login
            </a>

            <a
              href="/register"
              className="bg-gray-400 text-gray-800 px-6 py-3 rounded-lg text-lg hover:bg-gray-300 transition"
            >
              Register
            </a>
          </div>
        </div>

      </div>
    </div>
  );
}
