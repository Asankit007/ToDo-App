import { useState } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";

export default function Login() {
  const navigate = useNavigate();

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [message, setMessage] = useState("");

  const handleLogin = async () => {
    if (!email || !password) {
      setMessage("Email and password required");
      return;
    }

    try {
      const res = await axios.post("http://127.0.0.1:8000/auth/login", {
        email,
        password,
      });

      localStorage.setItem("token", res.data.access_token);
      setMessage("Login successful!");

      setTimeout(() => navigate("/dashboard"), 1000);
    } catch (err) {
      setMessage("Invalid email or password");
    }
  };

  return (
    <div className="flex items-center justify-center min-h-screen bg-[#BEE0FF] px-4">
      <div className="w-full max-w-lg bg-white p-10 rounded-2xl shadow-md border">

        <h2 className="text-2xl font-bold text-gray-800 mb-6">Login</h2>

        {message && (
          <p className="text-center mb-4 text-red-600 font-medium">{message}</p>
        )}

        <div className="mb-6">
          <label className="text-gray-900 text-lg font-medium">Email</label>
          <input
            type="email"
            className="mt-2 w-full border rounded-xl p-4 text-gray-700 focus:outline-blue-300"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
          />
        </div>

        <div className="mb-2">
          <label className="text-gray-900 text-lg font-medium">Password</label>
          <input
            type="password"
            className="mt-2 w-full border rounded-xl p-4 text-gray-700 focus:outline-blue-300"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
          />
        </div>

        <div className="text-right mb-6">
          <a href="/forgot-password" className="text-blue-600 font-medium hover:underline">
            Forgot Password?
          </a>
        </div>

        <button
          onClick={handleLogin}
          className="bg-[#1A2C4F] text-white w-full text-lg font-semibold py-3 rounded-xl hover:bg-[#162544] transition"
        >
          Login
        </button>

        <p className="text-center text-gray-700 mt-6">
          Don’t have an account?
          <button
            onClick={() => navigate("/register")}
            className="text-blue-600 font-semibold ml-1 hover:underline"
          >
            Register
          </button>
        </p>

      </div>
    </div>
  );
}
