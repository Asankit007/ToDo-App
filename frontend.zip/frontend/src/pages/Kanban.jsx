import { DragDropContext, Droppable, Draggable } from "react-beautiful-dnd";
import { useState } from "react";
import { useNavigate } from "react-router-dom";

export default function Kanban() {
  const navigate = useNavigate();

  const [columns, setColumns] = useState({
    todo: {
      name: "To Do",
      items: [
        { id: "1", title: "Buy groceries" },
        { id: "2", title: "Prepare presentation" },
      ],
    },
    inprogress: {
      name: "In Progress",
      items: [{ id: "3", title: "UI Design Fixes" }],
    },
    completed: {
      name: "Completed",
      items: [{ id: "4", title: "Submit report" }],
    },
    blocked: {
      name: "Blocked",
      items: [{ id: "5", title: "API Issue Pending" }],
    },
  });

  // ---- Drag & Drop Handler ----
  const handleDragEnd = (result) => {
    if (!result.destination) return;

    const { source, destination } = result;

    const sourceColumn = columns[source.droppableId];
    const destColumn = columns[destination.droppableId];

    const sourceItems = [...sourceColumn.items];
    const destItems = [...destColumn.items];

    const [removed] = sourceItems.splice(source.index, 1);
    destItems.splice(destination.index, 0, removed);

    setColumns({
      ...columns,
      [source.droppableId]: { ...sourceColumn, items: sourceItems },
      [destination.droppableId]: { ...destColumn, items: destItems },
    });
  };

  // ---- Delete Task ----
  const deleteTask = (colId, itemId) => {
    setColumns((prev) => ({
      ...prev,
      [colId]: {
        ...prev[colId],
        items: prev[colId].items.filter((task) => task.id !== itemId),
      },
    }));
  };

  // ---- Edit Task (navigate to edit page) ----
  const editTask = (colId, itemId) => {
    navigate(`/edit-task/${itemId}`);
  };

  return (
    <div className="p-4 sm:p-6 bg-[#E2F1E7] min-h-screen rounded-xl">

      <h1 className="text-3xl font-bold text-gray-800 mb-6">Kanban Board</h1>

      <DragDropContext onDragEnd={handleDragEnd}>
        <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">

          {Object.entries(columns).map(([colId, colData]) => (
            <div key={colId} className="bg-white rounded-xl p-4 shadow border flex flex-col">

              {/* COLUMN HEADER WITH COUNT */}
              <div className="flex justify-between items-center mb-4">
                <h2 className="font-bold text-gray-700 text-xl">
                  {colData.name}
                </h2>

                <span className="bg-blue-100 text-blue-700 px-3 py-1 rounded-lg text-sm font-semibold">
                  {colData.items.length}
                </span>
              </div>

              <Droppable droppableId={colId}>
                {(provided) => (
                  <div
                    {...provided.droppableProps}
                    ref={provided.innerRef}
                    className="space-y-3 min-h-[50px] flex-1"
                  >
                    {colData.items.map((item, index) => (
                      <Draggable
                        key={item.id}
                        draggableId={item.id}
                        index={index}
                      >
                        {(provided) => (
                          <div
                            className="bg-gray-100 p-4 rounded-xl shadow-sm border flex justify-between items-center"
                            ref={provided.innerRef}
                            {...provided.draggableProps}
                            {...provided.dragHandleProps}
                          >
                            <span className="text-gray-700 font-medium">
                              {item.title}
                            </span>

                            <div className="flex gap-2">
                              <button
                                onClick={() => editTask(colId, item.id)}
                                className="px-3 py-1 bg-blue-500 text-white rounded-lg text-sm"
                              >
                                Edit
                              </button>

                              <button
                                onClick={() => deleteTask(colId, item.id)}
                                className="px-3 py-1 bg-red-500 text-white rounded-lg text-sm"
                              >
                                Delete
                              </button>
                            </div>
                          </div>
                        )}
                      </Draggable>
                    ))}

                    {provided.placeholder}
                  </div>
                )}
              </Droppable>

              {/* ADD TASK BUTTON ONLY FOR TO DO COLUMN */}
              {colId === "todo" && (
                <button
                  onClick={() => navigate("/add-task")}
                  className="mt-4 bg-blue-600 text-white py-2 rounded-lg hover:bg-blue-700 transition text-center"
                >
                  + Add Task
                </button>
              )}

            </div>
          ))}

        </div>
      </DragDropContext>
    </div>
  );
}
