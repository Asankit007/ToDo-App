import { useLocation } from "react-router-dom";
import { useState, useEffect } from "react";

export default function AddTask() {
  const location = useLocation();
  const editData = location.state; // task data from Tasks.jsx

  const [title, setTitle] = useState("");
  const [desc, setDesc] = useState("");
  const [priority, setPriority] = useState("");
  const [date, setDate] = useState("");

  // Fill form if editing
  useEffect(() => {
    if (editData) {
      setTitle(editData.title);
      setDesc(editData.description || "");
      setPriority(editData.priority);
      setDate(editData.date);
    }
  }, []);

  return (
    <div className="p-6 flex justify-center">
      <div className="bg-white p-8 rounded-xl border shadow-sm max-w-xl w-full">

        <h2 className="text-2xl font-bold text-gray-800 mb-6">
          {editData ? "Edit Task" : "Add New Task"}
        </h2>

        <label className="font-semibold text-gray-700">Title</label>
        <input
          className="border p-3 rounded-md w-full mb-4 mt-1"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
        />

        <label className="font-semibold text-gray-700">Description</label>
        <textarea
          className="border p-3 rounded-md w-full mb-4 mt-1"
          value={desc}
          onChange={(e) => setDesc(e.target.value)}
        />

        <label className="font-semibold text-gray-700">Priority</label>
        <select
          className="border p-3 rounded-md w-full mb-4 mt-1"
          value={priority}
          onChange={(e) => setPriority(e.target.value)}
        >
          <option value="">Choose Priority</option>
          <option value="High">High</option>
          <option value="Medium">Medium</option>
          <option value="Low">Low</option>
        </select>

        <label className="font-semibold text-gray-700">Due Date</label>
        <input
          className="border p-3 rounded-md w-full mb-6 mt-1"
          type="date"
          value={date}
          onChange={(e) => setDate(e.target.value)}
        />

        {/* BUTTON */}
        <button className="bg-blue-600 hover:bg-blue-700 w-full py-3 text-white rounded-lg">
          {editData ? "Update Task" : "Create Task"}
        </button>
      </div>
    </div>
  );
}
