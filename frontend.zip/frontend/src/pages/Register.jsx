import { useState } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";

export default function Register() {
  const navigate = useNavigate();

  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [message, setMessage] = useState("");

  const handleRegister = async () => {
    if (!name || !email || !password) {
      setMessage("All fields are required");
      return;
    }

    try {
      const res = await axios.post("http://127.0.0.1:8000/auth/signup", {
        name,
        email,
        password,
      });

      setMessage("Account created successfully!");
      setTimeout(() => navigate("/login"), 1500);
    } catch (err) {
      setMessage("Email already exists or server error");
    }
  };

  return (
    <div className="flex items-center justify-center min-h-screen bg-gray-100 px-4">
      <div className="w-full max-w-md bg-white p-8 rounded-xl border shadow-sm">
        <h2 className="text-2xl font-bold text-gray-800 mb-2">Create Account</h2>
        <p className="text-gray-500 mb-6">Register to get started</p>

        {message && (
          <p className="text-center mb-4 text-red-600 font-medium">{message}</p>
        )}

        <div className="mb-4">
          <label className="text-gray-700 font-semibold">Full Name</label>
          <input
            type="text"
            className="border p-3 w-full rounded-md mt-1"
            placeholder="John Doe"
            value={name}
            onChange={(e) => setName(e.target.value)}
          />
        </div>

        <div className="mb-4">
          <label className="text-gray-700 font-semibold">Email</label>
          <input
            type="email"
            className="border p-3 w-full rounded-md mt-1"
            placeholder="example@gmail.com"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
          />
        </div>

        <div className="mb-6">
          <label className="text-gray-700 font-semibold">Password</label>
          <input
            type="password"
            className="border p-3 w-full rounded-md mt-1"
            placeholder="********"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
          />
        </div>

        <button
          onClick={handleRegister}
          className="w-full bg-blue-600 hover:bg-blue-700 text-white font-semibold py-3 rounded-lg transition"
        >
          Create Account
        </button>

        <p className="text-center text-sm text-gray-600 mt-4">
          Already have an account?{" "}
          <button
            onClick={() => navigate("/login")}
            className="text-blue-600"
          >
            Login
          </button>
        </p>
      </div>
    </div>
  );
}
