export default function TaskDetails() {
  return (
    <div className="p-2 sm:p-6 flex justify-center">

      <div className="bg-white p-8 rounded-xl border shadow-sm max-w-2xl w-full">
        
        <h1 className="text-2xl font-bold text-gray-800 mb-4">Task Title</h1>
        <p className="text-gray-600 mb-6">
          This is where the full description of the task appears...
        </p>

        <div className="bg-gray-100 p-4 rounded-lg mb-4">
          <h3 className="font-semibold text-gray-700 mb-2">Subtasks</h3>
          <div className="p-3 bg-white border rounded-lg mb-2">Subtask 1</div>
          <div className="p-3 bg-white border rounded-lg mb-2">Subtask 2</div>
        </div>

      </div>

    </div>
  );
}
