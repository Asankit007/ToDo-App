export default function Dashboard() {
  return (
    <div className="p-6 bg-[#C5F3DA] min-h-screen">

      <h1 className="text-3xl font-bold text-gray-800 mb-8">Dashboard</h1>

      {/* Add Task Section */}
      <div className="bg-white p-10 rounded-2xl shadow-sm border max-w-xl">

        <h2 className="text-xl font-semibold text-gray-800 mb-4">
          Create Your Task
        </h2>

        <p className="text-gray-600 mb-6">
          Start by adding a new task to manage and track your workflow.
        </p>

        <a
          href="/add-task"
          className="bg-blue-600 text-white font-semibold px-6 py-3 rounded-xl hover:bg-blue-700 transition"
        >
          + Add Task
        </a>

      </div>

    </div>
  );
}
