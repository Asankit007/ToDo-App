import { useState } from "react";
import { useNavigate } from "react-router-dom";

export default function Tasks() {
  const navigate = useNavigate();

  const [selectedDate, setSelectedDate] = useState("");
  const [showDatePicker, setShowDatePicker] = useState(false);

  const demoTasks = [
    {
      id: 1,
      title: "Design Homepage UI",
      priority: "High",
      date: "2025-01-15",
    },
    {
      id: 2,
      title: "Write API Documentation",
      priority: "Medium",
      date: "2025-01-20",
    },
    {
      id: 3,
      title: "Fix Login Bug",
      priority: "Low",
      date: "2025-01-25",
    },
  ];

  return (
    <div className="p-6 min-h-screen bg-[#E2F1E7] rounded-xl">

      {/* PAGE TITLE */}
      <h1 className="text-3xl font-bold text-gray-800 mb-6">Tasks</h1>

      {/* TOP BAR */}
      <div className="flex items-center gap-4 mb-6 relative">

        {/* Search */}
        <input
          className="border p-3 rounded-lg w-1/3 bg-white shadow-sm"
          placeholder="Search by title..."
        />

        {/* Priority Filter */}
        <select className="border p-3 rounded-lg bg-white shadow-sm">
          <option>Priority</option>
          <option>High</option>
          <option>Medium</option>
          <option>Low</option>
        </select>

        {/* DATE FILTER BUTTON */}
        <div className="flex items-center gap-3 relative">

          {/* Button */}
          <button
            className="border p-3 rounded-lg bg-white hover:bg-gray-50 shadow-sm"
            onClick={() => setShowDatePicker(!showDatePicker)}
          >
            Filter by Date
          </button>

          {/* Selected Date Field */}
          <input
            type="text"
            value={selectedDate}
            readOnly
            placeholder="No date"
            className="border p-3 rounded-lg w-40 bg-white shadow-sm text-gray-700"
          />

          {/* Date Picker Dropdown */}
          {showDatePicker && (
            <input
              type="date"
              className="absolute top-14 left-0 border p-2 rounded-lg bg-white shadow-md"
              onChange={(e) => {
                setSelectedDate(e.target.value);
                setShowDatePicker(false);
              }}
            />
          )}
        </div>

        {/* Add Task Button */}
        <button
          className="bg-blue-600 text-white px-5 py-3 rounded-lg hover:bg-blue-700 ml-auto shadow-md"
          onClick={() => navigate("/add-task")}
        >
          + Add Task
        </button>

      </div>

      {/* TASK LIST */}
      <div className="bg-white p-6 rounded-xl border shadow-md">

        {demoTasks.map((task) => (
          <div
            key={task.id}
            className="border p-4 rounded-xl mb-4 flex justify-between items-center bg-gray-50 shadow-sm"
          >
            <div>
              <h3 className="font-bold text-gray-900 text-lg">{task.title}</h3>
              <p className="text-gray-600 text-sm">
                Priority: {task.priority} &nbsp; | &nbsp; Due: {task.date}
              </p>
            </div>

            {/* BUTTONS */}
            <div className="flex gap-3">
              <button
                className="px-4 py-2 bg-yellow-500 text-white rounded-lg hover:bg-yellow-600 shadow"
                onClick={() =>
                  navigate(`/add-task?id=${task.id}`, { state: task })
                }
              >
                Edit
              </button>

              <button className="px-4 py-2 bg-red-500 text-white rounded-lg hover:bg-red-600 shadow">
                Delete
              </button>
            </div>
          </div>
        ))}

      </div>
    </div>
  );
}
