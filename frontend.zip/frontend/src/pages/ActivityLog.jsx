export default function ActivityLog() {
  const logs = [
    // ---------- LOGIN ACTIVITY ----------
    {
      id: 101,
      action: "User Logged In",
      description: "You logged into your account successfully",
      time: "2025-01-23 09:12 AM",
      type: "login",
    },

    // ---------- PROFILE UPDATE ----------
    {
      id: 102,
      action: "Profile Updated",
      description: "You updated your profile information",
      time: "2025-01-23 09:20 AM",
      type: "profile",
    },

    // ---------- EXISTING YOUR ACTIVITIES ----------
    {
      id: 1,
      action: "Task Created",
      description: "You added a new task: Design Homepage UI",
      time: "2025-01-20 10:32 AM",
      type: "create",
    },
    {
      id: 2,
      action: "Task Updated",
      description: "You updated task: Write API Documentation",
      time: "2025-01-21 02:15 PM",
      type: "update",
    },
    {
      id: 3,
      action: "Moved to In Progress",
      description: "Task Fix Login Bug moved from To Do",
      time: "2025-01-22 09:10 AM",
      type: "progress",
    },
    {
      id: 4,
      action: "Task Deleted",
      description: "Removed task: Old wireframe cleanup",
      time: "2025-01-22 04:28 PM",
      type: "delete",
    },
  ];

  // Badge colors for each activity type
  const badgeColor = {
    login: "bg-purple-100 text-purple-700",
    profile: "bg-indigo-100 text-indigo-700",
    create: "bg-green-100 text-green-700",
    update: "bg-blue-100 text-blue-700",
    progress: "bg-yellow-100 text-yellow-700",
    delete: "bg-red-100 text-red-700",
  };

  return (
    <div className="min-h-screen bg-[#E2F1E7] p-6 rounded-xl">
      
      <h1 className="text-3xl font-bold text-gray-800 mb-6">Activity Log</h1>

      <div className="bg-white p-6 rounded-xl shadow border">

        {/* Table Header */}
        <div className="grid grid-cols-4 font-semibold text-gray-600 border-b pb-3 mb-4">
          <span>Activity</span>
          <span>Description</span>
          <span>Status</span>
          <span>Time</span>
        </div>

        {/* Logs List */}
        <div className="space-y-4">
          {logs.map((log) => (
            <div
              key={log.id}
              className="grid grid-cols-4 items-center bg-gray-50 p-4 rounded-lg border"
            >
              {/* Activity Title */}
              <span className="font-bold text-gray-800">{log.action}</span>

              {/* Description */}
              <span className="text-gray-600">{log.description}</span>

              {/* Status Badge */}
              <span
                className={`px-3 py-1 rounded-full text-sm font-semibold text-center ${badgeColor[log.type]}`}
              >
                {log.type.charAt(0).toUpperCase() + log.type.slice(1)}
              </span>

              {/* Timestamp */}
              <span className="text-gray-500 text-sm">{log.time}</span>
            </div>
          ))}
        </div>

      </div>
    </div>
  );
}
