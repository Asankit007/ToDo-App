export default function Settings() {
  return (
    <div className="min-h-screen bg-[#E2F1E7] p-6 rounded-xl">

      {/* PAGE HEADER */}
      <h1 className="text-3xl font-bold text-gray-800 mb-8">Settings</h1>

      {/* SETTINGS GRID */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">

        {/* THEME CARD */}
        <div className="bg-white p-8 rounded-2xl shadow-md border">
          <h2 className="text-xl font-bold text-gray-800 mb-3">
            Theme
          </h2>
          {/* <p className="text-gray-500 mb-6">
            Light / Dark toggle will go here
          </p> */}

          <div className="flex items-center gap-3">
            <span className="font-medium text-gray-600">Mode:</span>
            <button className="bg-gray-200 px-4 py-2 rounded-lg">Light</button>
            <button className="bg-gray-200 px-4 py-2 rounded-lg">Dark</button>
          </div>
        </div>

        {/* CHANGE PASSWORD CARD */}
        <div className="bg-white p-8 rounded-2xl shadow-md border">
          <h2 className="text-xl font-bold text-gray-800 mb-3">
            Change Password
          </h2>
          {/* <p className="text-gray-500 mb-6">
            Password fields will go here
          </p> */}

          <div className="space-y-4">
            <input
              type="password"
              className="border p-3 rounded-lg w-full"
              placeholder="Current Password"
            />
            <input
              type="password"
              className="border p-3 rounded-lg w-full"
              placeholder="New Password"
            />
            <input
              type="password"
              className="border p-3 rounded-lg w-full"
              placeholder="Confirm Password"
            />

            <button className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded-lg font-semibold">
              Update Password
            </button>
          </div>
        </div>

        {/* EXPORT TASKS CARD */}
        <div className="bg-white p-8 rounded-2xl shadow-md border lg:col-span-2">
          <h2 className="text-xl font-bold text-gray-800 mb-3">
            Export Tasks
          </h2>
          {/* <p className="text-gray-500 mb-6">
            Export UI goes here
          </p> */}

          <div className="flex gap-4">
            <button className="bg-green-600 hover:bg-green-700 text-white px-6 py-3 rounded-lg font-semibold">
              Export as CSV
            </button>
            <button className="bg-purple-600 hover:bg-purple-700 text-white px-6 py-3 rounded-lg font-semibold">
              Export as PDF
            </button>
          </div>
        </div>

      </div>
    </div>
  );
}
