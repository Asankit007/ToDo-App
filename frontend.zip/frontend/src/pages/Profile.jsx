import { useState } from "react";
import { FiTrash2 } from "react-icons/fi";
import { IoCamera } from "react-icons/io5";

export default function Profile() {
  const [profilePic, setProfilePic] = useState(null);

  // Upload Image
  const handleImageUpload = (e) => {
    const file = e.target.files[0];
    if (file) {
      setProfilePic(URL.createObjectURL(file));
    }
  };

  // Remove Image
  const removeImage = () => {
    setProfilePic(null);
  };

  return (
    <div className="p-6 flex justify-center bg-[#E2F1E7] min-h-screen">

      <div className="bg-white p-8 rounded-2xl border shadow-md max-w-xl w-full">

        <h1 className="text-2xl font-bold text-gray-800 mb-6 text-center">
          Profile Settings
        </h1>

        {/* Profile Picture Section */}
        <div className="relative w-32 h-32 mx-auto mb-6">

          {/* Picture Preview */}
          {profilePic ? (
            <img
              src={profilePic}
              alt="Profile"
              className="w-32 h-32 rounded-full object-cover border shadow"
            />
          ) : (
            <div className="w-32 h-32 rounded-full bg-gray-200 border flex items-center justify-center text-gray-500">
              No Image
            </div>
          )}

          {/* Camera Button */}
          <label className="absolute bottom-1 right-1 bg-blue-600 text-white p-2 rounded-full cursor-pointer hover:bg-blue-700 shadow">
            <IoCamera size={18} />
            <input type="file" className="hidden" onChange={handleImageUpload} />
          </label>

          {/* Delete Button */}
          {profilePic && (
            <button
              onClick={removeImage}
              className="absolute top-1 right-1 bg-red-500 text-white p-1 rounded-full shadow hover:bg-red-600"
            >
              <FiTrash2 size={16} />
            </button>
          )}
        </div>

        {/* Form Fields */}
        <label className="text-gray-700 font-semibold">Name</label>
        <input
          className="border p-3 w-full rounded-md mb-4 mt-1"
          placeholder="Your name"
        />

        <label className="text-gray-700 font-semibold">Bio</label>
        <textarea
          className="border p-3 w-full rounded-md mb-4 mt-1"
          placeholder="Write something..."
        ></textarea>

        <button className="bg-blue-600 hover:bg-blue-700 text-white py-3 rounded-lg w-full font-semibold">
          Save Changes
        </button>

      </div>
    </div>
  );
}
