import { useLocation } from "react-router-dom";

export default function EditTask() {
  const location = useLocation();
  const task = location.state?.task; // receives task from Kanban

  return (
    <div className="p-6 flex justify-center bg-[#D2F3E0] min-h-screen">

      <div className="bg-white p-8 rounded-xl shadow-md border max-w-xl w-full">

        <h2 className="text-2xl font-bold text-gray-800 mb-6">Edit Task</h2>

        {/* Title */}
        <label className="text-gray-700 font-semibold">Title</label>
        <input
          defaultValue={task?.title}
          className="border p-3 rounded-md w-full mb-4 mt-1"
        />

        {/* Description */}
        <label className="text-gray-700 font-semibold">Description</label>
        <textarea
          defaultValue={task?.description}
          className="border p-3 rounded-md w-full mb-4 mt-1"
          rows={3}
        ></textarea>

        {/* Priority */}
        <label className="text-gray-700 font-semibold">Priority</label>
        <select
          defaultValue={task?.priority}
          className="border p-3 rounded-md w-full mb-4 mt-1"
        >
          <option>High</option>
          <option>Medium</option>
          <option>Low</option>
        </select>

        {/* Due Date */}
        <label className="text-gray-700 font-semibold">Due Date</label>
        <input
          type="date"
          defaultValue={task?.dueDate}
          className="border p-3 rounded-md w-full mb-6 mt-1"
        />

        {/* Save Changes */}
        <button className="bg-blue-600 text-white p-3 rounded-lg w-full hover:bg-blue-700">
          Update Task
        </button>

      </div>
    </div>
  );
}
