export default function ResetPassword() {
  return (
    <div className="flex items-center justify-center min-h-screen bg-gray-100 px-4">
      <div className="w-full max-w-md bg-white p-8 rounded-xl border shadow-sm">

        <h2 className="text-2xl font-bold text-gray-800 mb-4">Reset Password</h2>
        <p className="text-gray-500 mb-6">
          Create a new password for your account.
        </p>

        {/* New Password */}
        <div className="mb-4">
          <label className="text-gray-700 font-semibold">New Password</label>
          <input
            type="password"
            className="mt-2 w-full border rounded-xl p-3"
            placeholder="Enter new password"
          />
        </div>

        {/* Confirm Password */}
        <div className="mb-6">
          <label className="text-gray-700 font-semibold">Confirm Password</label>
          <input
            type="password"
            className="mt-2 w-full border rounded-xl p-3"
            placeholder="Confirm new password"
          />
        </div>

        {/* Reset Button */}
        <button className="w-full bg-blue-600 text-white py-3 rounded-xl text-lg font-semibold hover:bg-blue-700 transition">
          Reset Password
        </button>

      </div>
    </div>
  );
}
