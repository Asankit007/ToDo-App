import { Link } from "react-router-dom";

export default function ForgotPassword() {
  return (
    <div className="flex items-center justify-center min-h-screen bg-[#BEE0FF] px-4">
      <div className="w-full max-w-lg bg-white p-10 rounded-2xl shadow-md border">

        <h2 className="text-2xl font-bold text-gray-800 mb-6">Reset Password</h2>

        <label className="text-gray-700 font-medium">Enter your email</label>
        <input
          type="email"
          className="border p-4 rounded-xl w-full mt-2 mb-6"
          placeholder="example@gmail.com"
        />

        <Link
          to="/reset-password"
          className="block bg-blue-600 text-white text-center py-3 rounded-xl hover:bg-blue-700 transition"
        >
          Send OTP
        </Link>

      </div>
    </div>
  );
}
