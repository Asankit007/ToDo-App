import { Link } from "react-router-dom";

export default function Sidebar() {
  return (
    <div className="w-64 bg-white min-h-screen border-r p-6">

      <h2 className="text-2xl font-bold mb-8 text-gray-800">Task Manager</h2>

      <nav className="space-y-4 text-lg">

        <Link to="/dashboard" className="block hover:text-blue-600">
          Dashboard
        </Link>

        <Link to="/tasks" className="block hover:text-blue-600">
          List View
        </Link>

        <Link to="/kanban" className="block hover:text-blue-600">
          Kanban
        </Link>

        <Link to="/analytics" className="block hover:text-blue-600">
          Analytics
        </Link>

        <Link to="/settings" className="block hover:text-blue-600">
          Settings
        </Link>

        <Link to="/profile" className="block hover:text-blue-600">
          Profile
        </Link>

        <Link to="/activity" className="block hover:text-blue-600">
          Activity Log
        </Link>

        {/* <Link
          to="/add-task"
          className="mt-6 inline-block bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700"
        >
          + Add Task
        </Link> */}

      </nav>
    </div>
  );
}
